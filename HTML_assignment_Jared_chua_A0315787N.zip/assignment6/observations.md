# Observations for Assignment 6

## Q1

The script dynamically inserts the html text `Hello World` into the document body.

## Q2

The script creates an alert box when the page is visited, where the string `Hello World` appears as part of the notification modal.

## Q3

The script inserts the two html lines side by side, sequentially.

## Q4

The script inserts the html line onto the document, retaining the syntax that was included as part of the script.

# Quiz

# Q4

B

# Q5

A

# Q6

A

# Q7

A

# Q8

D

# Q9

B

# Q10

A

# Q11

C

# Q12

C

# Q13

C

# Q14

C

# Q15

D

# Q16

B
